<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class Items extends Component
{
    public function render()
    {
        return view('livewire.admin.items');
    }
}
