<?php

namespace App\Http\Livewire\Clients;

use Livewire\Component;

class Adjustment extends Component
{
    public function render()
    {
        return view('livewire.clients.adjustment');
    }
}
