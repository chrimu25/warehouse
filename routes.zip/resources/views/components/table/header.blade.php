<header class="card-header">
  {{$slot}}
</header>