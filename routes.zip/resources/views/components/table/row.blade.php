<tr {{$attributes->merge(['class'=>'bg-gray-50 hover:bg-gray-100'])}}>
    {{$slot}}
</tr>