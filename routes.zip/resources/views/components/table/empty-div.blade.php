<tr class="card empty">
    <td class="card-content w-full" colspan="{{ $slot }}">
      <div>
        <span class="icon large"><i class="mdi mdi-emoticon-sad mdi-48px"></i></span>
      </div>
      <p>Nothing's here…</p>
    </td>
  </tr>