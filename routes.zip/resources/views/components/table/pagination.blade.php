<div class="table-pagination">
    <div class="flex items-center justify-between">
      {{$slot}}
    </div>
  </div>