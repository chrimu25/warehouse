<th {{$attributes->merge(['class'=>'px-6 py-3 bg-gray-800 text-left text-xs font-medium text-white uppercase tracking-wider'])}}>
    <span class="text-left text-xs leading-5 font-medium text-white uppercase tracking-wider">
        {{$slot}}
    </span>
</th>