<x-app-layout title="Unities">
    <div class="bg-gray-100">
        <div class="min-h-screen flex flex-col items-center sm:pt-0">
            @livewire('admin.unities')
        </div>
    </div>
</x-app-layout>
